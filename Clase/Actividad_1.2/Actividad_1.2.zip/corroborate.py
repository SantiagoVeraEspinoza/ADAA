import re
import sys

def isFormat(line):
    if re.search("^\d+:\s\d+", line): return True

    return False

def getResultingLine():
    result_list = []
    count = 0
    for line in sys.stdin:
        # Process each line of input
        line = line.strip()
        if isFormat(line):
            line = line.split(": ")
            
            result_line = line[0] + " " + line[1][:-1] + "\n"
            if line[1][-1] == "}": result_line = line[0] + " " + line[1][:-2] + "\n"
            result_list.append(result_line)

            if line[1][-1] == "}" and count < 1:
                result_list.append("\n")
                count += 1

    result_list[-1] = result_list[-1][:-1]

    return result_list

def main():
    if len(sys.argv) != 2:
        print("Usage: python process_output.py <file_path>")
        return

    file_path = sys.argv[1]

    result = getResultingLine()

    with open(file_path, 'r') as file:
        lines = file.readlines()
        if lines == result:
            print(0)
            sys.exit(0)

    print(1)

if __name__ == "__main__":
    main()
