#!/bin/bash

FOLDER_PATH="./tests"
OUTPUT_FILE="./output.txt"

find "$FOLDER_PATH" -type f > "$OUTPUT_FILE"

echo -e "\nFile paths saved to $OUTPUT_FILE\n"

g++ -o main main.cpp

echo -e "Executable created"

while IFS= read -r FILE_PATH; do
    echo -e "\nRunning test on $FILE_PATH..."
    ./main < "$FILE_PATH"
    sleep 2
done < "$OUTPUT_FILE"

echo -e "Deleting residual...\n"

rm -f ./output.txt
rm -f ./main.exe

sleep 1

echo -e "Done!"